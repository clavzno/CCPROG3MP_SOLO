Resources: https://www.youtube.com/watch?v=9OfeNDukXm8

32 bit pixel art size

1. Generic Regular Vending Machine
2. Generic Drink

Special Vending Machine
3. Chicken Breast
4. Chicken Drumsticks
5. Pork Shoulder
6. Pork Belly
7. Mix of Chicken (half breast, half drumsticks)
8. Mix of Pork (half shoulder, half belly)
9. Cup of white Rice
10. Adobo Sauce

Menu
11. Create Regular Vending Machine - Red DONE
12. Create Special Vending Machine - Blue DONE
13. Your Regular Vending Machine is Ready! - Red w Items DONE
14. Your Special Vending Machine is Ready! - Blue with Items DONE
15. Maintenance Option - Gear DONE
16. Maintenance: Restock - Golden Plus - DONE
17. Maintenace: Change Price - Reset Icon - DONE
18. Maintenance: Collect and Replenish Money - Money Icon- DONE
19. Maintenance: Print summary of transactions - Receipt DONE
20. Adobo final product in box - DONE


## Image References (APA Format)
Constantine Theo Remular (2023) - Replenish Money Icon, Reset Icon, Gold Plus
Kairosoft games ios. (n.d.). Weebly; Weebly. Retrieved August 5, 2023, from https://laseminsurance.weebly.com/kairosoft-games-ios.html 
    Vending Machine Inspiration - Kairosoft Games - Game Dev Story
Pixel Gear | Pixel Art Maker. (n.d.). Pixel Art Maker; Pixel Art Maker. Retrieved August 5, 2023, from https://pixelartmaker.com/art/9ee37f666991c7d
    Maintenance Gear Inspiration - Pixel Art Maker
Icon of Receipt or Packing Slip for Shopping and Retail Concept. Flat Filled Outline Style. Pixel Perfect 64x64. Editable Stroke Stock Vector - Illustration of bill, cute: 153281827. (n.d.). DreamsTime. Retrieved August 5, 2023, from https://www.dreamstime.com/icon-receipt-packing-slip-shopping-retail-concept-flat-filled-outline-style-pixel-perfect-editable-stroke-image153281827
    Print Transactions/Receipt Inspiration - DreamsTime - Elena Andreeva
Lee_Pipez. (2014, March 20). “PORK ADOBO RECIPE” or “ADOBONG BABOY RECIPE.” All Recipes 101; All Recipes 101. http://filrecipes101.blogspot.com/2014/03/pork-adobo-recipe-or-adobong-baboy.html
    Adobo Inspiration - All Recipes 101 - Lee_Pipez
Buy eco takeouts bpa  3 items on Bonanza. (n.d.). Bonanza. Retrieved August 5, 2023, from https://www.bonanza.com/items/search?q%5Bsearch_description%5D=1&q%5Bsearch_term%5D=eco+takeouts+bpa
    Takeout Box Inspiration - Bonanza

All other sprites used are made by me, Angelica Therese I. Clavano. 

